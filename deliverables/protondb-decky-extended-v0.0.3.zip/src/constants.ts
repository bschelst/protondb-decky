export const appTypes = {
  1: 'game',
  2: 'software',
  4: 'tool',
  8: 'demo',
  2048: 'video',
  65536: 'playtest'
}
