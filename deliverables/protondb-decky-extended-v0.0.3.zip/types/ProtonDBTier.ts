type ProtonDBTier =
  | 'borked'
  | 'platinum'
  | 'gold'
  | 'silver'
  | 'bronze'
  | 'pending'

export default ProtonDBTier
